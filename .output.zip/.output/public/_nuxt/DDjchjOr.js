const e={welcome:{t:0,b:{t:2,i:[{t:3}],s:"Xush kelibsiz!"}}};export{e as default};
