const e={welcome:{t:0,b:{t:2,i:[{t:3}],s:"Добро пожаловать!"}}};export{e as default};
