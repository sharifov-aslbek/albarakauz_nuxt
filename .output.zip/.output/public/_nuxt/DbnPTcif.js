function i(e,n=[],o){const s={};return Object.getOwnPropertyNames(e).forEach(t=>{n.includes(t)||(s[t]=e[t])}),Object.assign(s,o)}export{i as o};
